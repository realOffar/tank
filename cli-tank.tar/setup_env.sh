sudo apt install build-essential
sudo apt install gdb
sudo apt install vim
sudo apt install libncurses5-dev libncursesw5-dev
