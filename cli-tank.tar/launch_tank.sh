export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.:../game

./tank
